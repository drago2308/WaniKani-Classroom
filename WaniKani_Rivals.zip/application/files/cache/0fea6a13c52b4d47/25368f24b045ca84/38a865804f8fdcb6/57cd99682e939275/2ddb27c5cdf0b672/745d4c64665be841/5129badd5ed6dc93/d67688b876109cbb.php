<?php 
/* Cachekey: cache/stash_default/doctrine/dc2_da83e9592ab334c754c82c58ea31ea34_[concrete\core\entity\page\relation\relation$classmetadata][1]/ */
/* Type: array */
/* Expiration: 2017-02-28T13:40:49+01:00 */



$loaded = true;
$expiration = 1488285649;

$data = array();

/* Child Type: object */
$data['return'] = unserialize(base64_decode('TzozNDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcQ2xhc3NNZXRhZGF0YSI6MTM6e3M6MTk6ImFzc29jaWF0aW9uTWFwcGluZ3MiO2E6MDp7fXM6MTE6ImNvbHVtbk5hbWVzIjthOjA6e31zOjEzOiJmaWVsZE1hcHBpbmdzIjthOjA6e31zOjEwOiJmaWVsZE5hbWVzIjthOjA6e31zOjE1OiJlbWJlZGRlZENsYXNzZXMiO2E6MDp7fXM6MTA6ImlkZW50aWZpZXIiO2E6MDp7fXM6MjE6ImlzSWRlbnRpZmllckNvbXBvc2l0ZSI7YjowO3M6NDoibmFtZSI7czo0MzoiQ29uY3JldGVcQ29yZVxFbnRpdHlcUGFnZVxSZWxhdGlvblxSZWxhdGlvbiI7czo5OiJuYW1lc3BhY2UiO3M6MzQ6IkNvbmNyZXRlXENvcmVcRW50aXR5XFBhZ2VcUmVsYXRpb24iO3M6NToidGFibGUiO2E6MTp7czo0OiJuYW1lIjtzOjg6IlJlbGF0aW9uIjt9czoxNDoicm9vdEVudGl0eU5hbWUiO3M6NDM6IkNvbmNyZXRlXENvcmVcRW50aXR5XFBhZ2VcUmVsYXRpb25cUmVsYXRpb24iO3M6MTE6ImlkR2VuZXJhdG9yIjtPOjMzOiJEb2N0cmluZVxPUk1cSWRcQXNzaWduZWRHZW5lcmF0b3IiOjA6e31zOjE4OiJpc01hcHBlZFN1cGVyY2xhc3MiO2I6MTt9'));

/* Child Type: integer */
$data['createdOn'] = 1487905382;
