<?php 
/* Cachekey: cache/stash_default/doctrine/dc2_da83e9592ab334c754c82c58ea31ea34_[concrete\core\entity\attribute\value\value\abstractvalue$classmetadata][1]/ */
/* Type: array */
/* Expiration: 2017-03-01T01:46:17+01:00 */



$loaded = true;
$expiration = 1488329177;

$data = array();

/* Child Type: object */
$data['return'] = unserialize(base64_decode('TzozNDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcQ2xhc3NNZXRhZGF0YSI6MTM6e3M6MTk6ImFzc29jaWF0aW9uTWFwcGluZ3MiO2E6MDp7fXM6MTE6ImNvbHVtbk5hbWVzIjthOjA6e31zOjEzOiJmaWVsZE1hcHBpbmdzIjthOjA6e31zOjEwOiJmaWVsZE5hbWVzIjthOjA6e31zOjE1OiJlbWJlZGRlZENsYXNzZXMiO2E6MDp7fXM6MTA6ImlkZW50aWZpZXIiO2E6MDp7fXM6MjE6ImlzSWRlbnRpZmllckNvbXBvc2l0ZSI7YjowO3M6NDoibmFtZSI7czo1NjoiQ29uY3JldGVcQ29yZVxFbnRpdHlcQXR0cmlidXRlXFZhbHVlXFZhbHVlXEFic3RyYWN0VmFsdWUiO3M6OToibmFtZXNwYWNlIjtzOjQyOiJDb25jcmV0ZVxDb3JlXEVudGl0eVxBdHRyaWJ1dGVcVmFsdWVcVmFsdWUiO3M6NToidGFibGUiO2E6MTp7czo0OiJuYW1lIjtzOjEzOiJBYnN0cmFjdFZhbHVlIjt9czoxNDoicm9vdEVudGl0eU5hbWUiO3M6NTY6IkNvbmNyZXRlXENvcmVcRW50aXR5XEF0dHJpYnV0ZVxWYWx1ZVxWYWx1ZVxBYnN0cmFjdFZhbHVlIjtzOjExOiJpZEdlbmVyYXRvciI7TzozMzoiRG9jdHJpbmVcT1JNXElkXEFzc2lnbmVkR2VuZXJhdG9yIjowOnt9czoxODoiaXNNYXBwZWRTdXBlcmNsYXNzIjtiOjE7fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1487905037;
