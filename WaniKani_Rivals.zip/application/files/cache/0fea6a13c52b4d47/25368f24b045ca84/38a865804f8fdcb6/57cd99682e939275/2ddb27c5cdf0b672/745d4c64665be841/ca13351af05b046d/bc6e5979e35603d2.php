<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\statistics\usagetracker\fileusagerepository@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-28T17:12:12+01:00 */



$loaded = true;
$expiration = 1488298332;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTowOnt9'));

/* Child Type: integer */
$data['createdOn'] = 1487913265;
