<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\express\entity\listener#prepersist@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-28T16:16:26+01:00 */



$loaded = true;
$expiration = 1488294986;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTowOnt9'));

/* Child Type: integer */
$data['createdOn'] = 1487905042;
