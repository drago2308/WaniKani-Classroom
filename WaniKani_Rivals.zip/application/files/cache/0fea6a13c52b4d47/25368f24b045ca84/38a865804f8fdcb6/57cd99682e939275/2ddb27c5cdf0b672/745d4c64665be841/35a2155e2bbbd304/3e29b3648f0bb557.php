<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\set$category@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-18T23:27:30+01:00 */



$loaded = true;
$expiration = 1487456850;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzozMDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcTWFueVRvT25lIjo0OntzOjEyOiJ0YXJnZXRFbnRpdHkiO3M6ODoiQ2F0ZWdvcnkiO3M6NzoiY2FzY2FkZSI7TjtzOjU6ImZldGNoIjtzOjQ6IkxBWlkiO3M6MTA6ImludmVyc2VkQnkiO3M6Mzoic2V0Ijt9aToxO086MzE6IkRvY3RyaW5lXE9STVxNYXBwaW5nXEpvaW5Db2x1bW4iOjc6e3M6NDoibmFtZSI7czoxMjoiYWtDYXRlZ29yeUlEIjtzOjIwOiJyZWZlcmVuY2VkQ29sdW1uTmFtZSI7czoxMjoiYWtDYXRlZ29yeUlEIjtzOjY6InVuaXF1ZSI7YjowO3M6ODoibnVsbGFibGUiO2I6MTtzOjg6Im9uRGVsZXRlIjtOO3M6MTY6ImNvbHVtbkRlZmluaXRpb24iO047czo5OiJmaWVsZE5hbWUiO047fX0='));

/* Child Type: integer */
$data['createdOn'] = 1487035362;
