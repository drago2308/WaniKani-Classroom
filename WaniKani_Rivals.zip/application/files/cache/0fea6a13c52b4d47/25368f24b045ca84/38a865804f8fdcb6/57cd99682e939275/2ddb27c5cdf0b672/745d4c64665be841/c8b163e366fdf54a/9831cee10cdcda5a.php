<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\statistics\usagetracker\stackusagerecord@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T13:41:30+01:00 */



$loaded = true;
$expiration = 1487940090;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO047czo4OiJyZWFkT25seSI7YjowO31pOjE7TzoyNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcVGFibGUiOjU6e3M6NDoibmFtZSI7czoxNjoiU3RhY2tVc2FnZVJlY29yZCI7czo2OiJzY2hlbWEiO047czo3OiJpbmRleGVzIjthOjI6e2k6MDtPOjI2OiJEb2N0cmluZVxPUk1cTWFwcGluZ1xJbmRleCI6NDp7czo0OiJuYW1lIjtzOjU6ImJsb2NrIjtzOjc6ImNvbHVtbnMiO2E6MTp7aTowO3M6ODoiYmxvY2tfaWQiO31zOjU6ImZsYWdzIjtOO3M6Nzoib3B0aW9ucyI7Tjt9aToxO086MjY6IkRvY3RyaW5lXE9STVxNYXBwaW5nXEluZGV4Ijo0OntzOjQ6Im5hbWUiO3M6MTg6ImNvbGxlY3Rpb25fdmVyc2lvbiI7czo3OiJjb2x1bW5zIjthOjI6e2k6MDtzOjEzOiJjb2xsZWN0aW9uX2lkIjtpOjE7czoyMToiY29sbGVjdGlvbl92ZXJzaW9uX2lkIjt9czo1OiJmbGFncyI7TjtzOjc6Im9wdGlvbnMiO047fX1zOjE3OiJ1bmlxdWVDb25zdHJhaW50cyI7TjtzOjc6Im9wdGlvbnMiO2E6MDp7fX19'));

/* Child Type: integer */
$data['createdOn'] = 1487541297;
