<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\express\entity$default_edit_form@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-28T22:20:04+01:00 */



$loaded = true;
$expiration = 1488316804;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7TzoyOToiRG9jdHJpbmVcT1JNXE1hcHBpbmdcT25lVG9PbmUiOjY6e3M6MTI6InRhcmdldEVudGl0eSI7czo0OiJGb3JtIjtzOjg6Im1hcHBlZEJ5IjtOO3M6MTA6ImludmVyc2VkQnkiO047czo3OiJjYXNjYWRlIjthOjE6e2k6MDtzOjc6InBlcnNpc3QiO31zOjU6ImZldGNoIjtzOjQ6IkxBWlkiO3M6MTM6Im9ycGhhblJlbW92YWwiO2I6MDt9fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1487905042;
