<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\site\locale$mspluralcases@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T21:42:00+01:00 */



$loaded = true;
$expiration = 1487968920;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcQ29sdW1uIjo5OntzOjQ6Im5hbWUiO047czo0OiJ0eXBlIjtzOjY6InN0cmluZyI7czo2OiJsZW5ndGgiO2k6MTAwMDtzOjk6InByZWNpc2lvbiI7aTowO3M6NToic2NhbGUiO2k6MDtzOjY6InVuaXF1ZSI7YjowO3M6ODoibnVsbGFibGUiO2I6MDtzOjc6Im9wdGlvbnMiO2E6MDp7fXM6MTY6ImNvbHVtbkRlZmluaXRpb24iO047fX0='));

/* Child Type: integer */
$data['createdOn'] = 1487541292;
