<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\notification\notification@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T07:40:20+01:00 */



$loaded = true;
$expiration = 1487918420;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTo0OntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO047czo4OiJyZWFkT25seSI7YjowO31pOjE7TzozNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcSW5oZXJpdGFuY2VUeXBlIjoxOntzOjU6InZhbHVlIjtzOjY6IkpPSU5FRCI7fWk6MjtPOjQwOiJEb2N0cmluZVxPUk1cTWFwcGluZ1xEaXNjcmltaW5hdG9yQ29sdW1uIjo1OntzOjQ6Im5hbWUiO3M6NDoidHlwZSI7czo0OiJ0eXBlIjtzOjY6InN0cmluZyI7czo2OiJsZW5ndGgiO047czo5OiJmaWVsZE5hbWUiO047czoxNjoiY29sdW1uRGVmaW5pdGlvbiI7Tjt9aTozO086MjY6IkRvY3RyaW5lXE9STVxNYXBwaW5nXFRhYmxlIjo1OntzOjQ6Im5hbWUiO3M6MTM6Ik5vdGlmaWNhdGlvbnMiO3M6Njoic2NoZW1hIjtOO3M6NzoiaW5kZXhlcyI7TjtzOjE3OiJ1bmlxdWVDb25zdHJhaW50cyI7TjtzOjc6Im9wdGlvbnMiO2E6MDp7fX19'));

/* Child Type: integer */
$data['createdOn'] = 1487541297;
