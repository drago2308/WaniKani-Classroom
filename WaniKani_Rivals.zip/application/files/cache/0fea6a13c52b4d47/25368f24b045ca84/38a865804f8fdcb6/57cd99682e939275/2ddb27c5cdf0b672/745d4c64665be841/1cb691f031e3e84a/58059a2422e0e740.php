<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\set$keys@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-18T16:50:18+01:00 */



$loaded = true;
$expiration = 1487433018;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzozMDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcT25lVG9NYW55Ijo2OntzOjg6Im1hcHBlZEJ5IjtzOjM6InNldCI7czoxMjoidGFyZ2V0RW50aXR5IjtzOjM4OiJcQ29uY3JldGVcQ29yZVxFbnRpdHlcQXR0cmlidXRlXFNldEtleSI7czo3OiJjYXNjYWRlIjthOjE6e2k6MDtzOjM6ImFsbCI7fXM6NToiZmV0Y2giO3M6NDoiTEFaWSI7czoxMzoib3JwaGFuUmVtb3ZhbCI7YjowO3M6NzoiaW5kZXhCeSI7Tjt9aToxO086Mjg6IkRvY3RyaW5lXE9STVxNYXBwaW5nXE9yZGVyQnkiOjE6e3M6NToidmFsdWUiO2E6MTp7czoxNDoiYXNEaXNwbGF5T3JkZXIiO3M6MzoiQVNDIjt9fX0='));

/* Child Type: integer */
$data['createdOn'] = 1487035362;
