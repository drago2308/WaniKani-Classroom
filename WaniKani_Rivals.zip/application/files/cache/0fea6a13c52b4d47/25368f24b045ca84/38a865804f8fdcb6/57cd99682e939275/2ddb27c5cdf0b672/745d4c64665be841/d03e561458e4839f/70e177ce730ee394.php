<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\site\sitetree$locale@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T13:28:19+01:00 */



$loaded = true;
$expiration = 1487939299;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzoyOToiRG9jdHJpbmVcT1JNXE1hcHBpbmdcT25lVG9PbmUiOjY6e3M6MTI6InRhcmdldEVudGl0eSI7czozMzoiXENvbmNyZXRlXENvcmVcRW50aXR5XFNpdGVcTG9jYWxlIjtzOjg6Im1hcHBlZEJ5IjtOO3M6MTA6ImludmVyc2VkQnkiO3M6NDoidHJlZSI7czo3OiJjYXNjYWRlIjtOO3M6NToiZmV0Y2giO3M6NDoiTEFaWSI7czoxMzoib3JwaGFuUmVtb3ZhbCI7YjowO31pOjE7TzozMToiRG9jdHJpbmVcT1JNXE1hcHBpbmdcSm9pbkNvbHVtbiI6Nzp7czo0OiJuYW1lIjtzOjEyOiJzaXRlTG9jYWxlSUQiO3M6MjA6InJlZmVyZW5jZWRDb2x1bW5OYW1lIjtzOjEyOiJzaXRlTG9jYWxlSUQiO3M6NjoidW5pcXVlIjtiOjA7czo4OiJudWxsYWJsZSI7YjoxO3M6ODoib25EZWxldGUiO047czoxNjoiY29sdW1uRGVmaW5pdGlvbiI7TjtzOjk6ImZpZWxkTmFtZSI7Tjt9fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1487541297;
