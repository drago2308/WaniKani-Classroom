<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\notification\notificationalert@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T15:36:18+01:00 */



$loaded = true;
$expiration = 1487946978;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO3M6NjI6IlxDb25jcmV0ZVxDb3JlXEVudGl0eVxOb3RpZmljYXRpb25cTm90aWZpY2F0aW9uQWxlcnRSZXBvc2l0b3J5IjtzOjg6InJlYWRPbmx5IjtiOjA7fWk6MTtPOjI2OiJEb2N0cmluZVxPUk1cTWFwcGluZ1xUYWJsZSI6NTp7czo0OiJuYW1lIjtzOjE4OiJOb3RpZmljYXRpb25BbGVydHMiO3M6Njoic2NoZW1hIjtOO3M6NzoiaW5kZXhlcyI7TjtzOjE3OiJ1bmlxdWVDb25zdHJhaW50cyI7TjtzOjc6Im9wdGlvbnMiO2E6MDp7fX19'));

/* Child Type: integer */
$data['createdOn'] = 1487541297;
