<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\site\tree@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-03-01T01:50:17+01:00 */



$loaded = true;
$expiration = 1488329417;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTo0OntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO047czo4OiJyZWFkT25seSI7YjowO31pOjE7TzozNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcSW5oZXJpdGFuY2VUeXBlIjoxOntzOjU6InZhbHVlIjtzOjY6IkpPSU5FRCI7fWk6MjtPOjQwOiJEb2N0cmluZVxPUk1cTWFwcGluZ1xEaXNjcmltaW5hdG9yQ29sdW1uIjo1OntzOjQ6Im5hbWUiO3M6ODoidHJlZVR5cGUiO3M6NDoidHlwZSI7czo2OiJzdHJpbmciO3M6NjoibGVuZ3RoIjtOO3M6OToiZmllbGROYW1lIjtOO3M6MTY6ImNvbHVtbkRlZmluaXRpb24iO047fWk6MztPOjI2OiJEb2N0cmluZVxPUk1cTWFwcGluZ1xUYWJsZSI6NTp7czo0OiJuYW1lIjtzOjk6IlNpdGVUcmVlcyI7czo2OiJzY2hlbWEiO047czo3OiJpbmRleGVzIjtOO3M6MTc6InVuaXF1ZUNvbnN0cmFpbnRzIjtOO3M6Nzoib3B0aW9ucyI7YTowOnt9fX0='));

/* Child Type: integer */
$data['createdOn'] = 1487913263;
