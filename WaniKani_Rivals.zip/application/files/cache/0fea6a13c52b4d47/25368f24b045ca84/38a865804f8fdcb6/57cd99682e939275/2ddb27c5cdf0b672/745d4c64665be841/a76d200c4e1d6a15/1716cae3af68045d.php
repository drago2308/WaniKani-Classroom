<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\set@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T08:01:52+01:00 */



$loaded = true;
$expiration = 1487919712;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO047czo4OiJyZWFkT25seSI7YjowO31pOjE7TzoyNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcVGFibGUiOjU6e3M6NDoibmFtZSI7czoxMzoiQXR0cmlidXRlU2V0cyI7czo2OiJzY2hlbWEiO047czo3OiJpbmRleGVzIjthOjI6e2k6MDtPOjI2OiJEb2N0cmluZVxPUk1cTWFwcGluZ1xJbmRleCI6NDp7czo0OiJuYW1lIjtzOjg6ImFzSGFuZGxlIjtzOjc6ImNvbHVtbnMiO2E6MTp7aTowO3M6ODoiYXNIYW5kbGUiO31zOjU6ImZsYWdzIjtOO3M6Nzoib3B0aW9ucyI7Tjt9aToxO086MjY6IkRvY3RyaW5lXE9STVxNYXBwaW5nXEluZGV4Ijo0OntzOjQ6Im5hbWUiO3M6NToicGtnSUQiO3M6NzoiY29sdW1ucyI7YToxOntpOjA7czo1OiJwa2dJRCI7fXM6NToiZmxhZ3MiO047czo3OiJvcHRpb25zIjtOO319czoxNzoidW5pcXVlQ29uc3RyYWludHMiO047czo3OiJvcHRpb25zIjthOjA6e319fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1487541296;
