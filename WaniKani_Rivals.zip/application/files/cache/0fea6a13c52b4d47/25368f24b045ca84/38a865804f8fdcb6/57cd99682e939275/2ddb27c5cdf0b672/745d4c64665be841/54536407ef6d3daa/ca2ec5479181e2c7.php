<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\express\entry@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T19:57:54+01:00 */



$loaded = true;
$expiration = 1487962674;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTozOntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO3M6NDU6IlxDb25jcmV0ZVxDb3JlXEVudGl0eVxFeHByZXNzXEVudHJ5UmVwb3NpdG9yeSI7czo4OiJyZWFkT25seSI7YjowO31pOjE7TzoyNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcVGFibGUiOjU6e3M6NDoibmFtZSI7czoyMDoiRXhwcmVzc0VudGl0eUVudHJpZXMiO3M6Njoic2NoZW1hIjtOO3M6NzoiaW5kZXhlcyI7TjtzOjE3OiJ1bmlxdWVDb25zdHJhaW50cyI7TjtzOjc6Im9wdGlvbnMiO2E6MDp7fX1pOjI7TzozNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5TGlzdGVuZXJzIjoxOntzOjU6InZhbHVlIjthOjE6e2k6MDtzOjM3OiJcQ29uY3JldGVcQ29yZVxFeHByZXNzXEVudHJ5XExpc3RlbmVyIjt9fX0='));

/* Child Type: integer */
$data['createdOn'] = 1487541297;
