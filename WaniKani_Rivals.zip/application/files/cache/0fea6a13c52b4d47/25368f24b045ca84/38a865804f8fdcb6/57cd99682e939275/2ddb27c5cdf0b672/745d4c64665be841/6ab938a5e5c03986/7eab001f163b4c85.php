<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\file\version@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T10:25:26+01:00 */



$loaded = true;
$expiration = 1487928326;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO047czo4OiJyZWFkT25seSI7YjowO31pOjE7TzoyNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcVGFibGUiOjU6e3M6NDoibmFtZSI7czoxMjoiRmlsZVZlcnNpb25zIjtzOjY6InNjaGVtYSI7TjtzOjc6ImluZGV4ZXMiO2E6Mzp7aTowO086MjY6IkRvY3RyaW5lXE9STVxNYXBwaW5nXEluZGV4Ijo0OntzOjQ6Im5hbWUiO3M6MTA6ImZ2RmlsZW5hbWUiO3M6NzoiY29sdW1ucyI7YToxOntpOjA7czoxMDoiZnZGaWxlbmFtZSI7fXM6NToiZmxhZ3MiO047czo3OiJvcHRpb25zIjtOO31pOjE7TzoyNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcSW5kZXgiOjQ6e3M6NDoibmFtZSI7czoxMToiZnZFeHRlbnNpb24iO3M6NzoiY29sdW1ucyI7YToxOntpOjA7czoxMToiZnZFeHRlbnNpb24iO31zOjU6ImZsYWdzIjtOO3M6Nzoib3B0aW9ucyI7Tjt9aToyO086MjY6IkRvY3RyaW5lXE9STVxNYXBwaW5nXEluZGV4Ijo0OntzOjQ6Im5hbWUiO3M6NjoiZnZUeXBlIjtzOjc6ImNvbHVtbnMiO2E6MTp7aTowO3M6NjoiZnZUeXBlIjt9czo1OiJmbGFncyI7TjtzOjc6Im9wdGlvbnMiO047fX1zOjE3OiJ1bmlxdWVDb25zdHJhaW50cyI7TjtzOjc6Im9wdGlvbnMiO2E6MDp7fX19'));

/* Child Type: integer */
$data['createdOn'] = 1487541297;
