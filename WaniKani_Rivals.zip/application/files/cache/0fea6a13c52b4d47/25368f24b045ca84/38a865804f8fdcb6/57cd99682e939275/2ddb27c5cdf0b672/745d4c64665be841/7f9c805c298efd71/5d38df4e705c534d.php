<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\site\locale$site@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T06:46:35+01:00 */



$loaded = true;
$expiration = 1487915195;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzozMDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcTWFueVRvT25lIjo0OntzOjEyOiJ0YXJnZXRFbnRpdHkiO3M6NDoiU2l0ZSI7czo3OiJjYXNjYWRlIjtOO3M6NToiZmV0Y2giO3M6NDoiTEFaWSI7czoxMDoiaW52ZXJzZWRCeSI7czo3OiJsb2NhbGVzIjt9aToxO086MzE6IkRvY3RyaW5lXE9STVxNYXBwaW5nXEpvaW5Db2x1bW4iOjc6e3M6NDoibmFtZSI7czo2OiJzaXRlSUQiO3M6MjA6InJlZmVyZW5jZWRDb2x1bW5OYW1lIjtzOjY6InNpdGVJRCI7czo2OiJ1bmlxdWUiO2I6MDtzOjg6Im51bGxhYmxlIjtiOjE7czo4OiJvbkRlbGV0ZSI7TjtzOjE2OiJjb2x1bW5EZWZpbml0aW9uIjtOO3M6OToiZmllbGROYW1lIjtOO319'));

/* Child Type: integer */
$data['createdOn'] = 1487541292;
