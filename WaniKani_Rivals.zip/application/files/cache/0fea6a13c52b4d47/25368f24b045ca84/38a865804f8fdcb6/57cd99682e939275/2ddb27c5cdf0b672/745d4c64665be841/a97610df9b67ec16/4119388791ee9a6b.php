<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\attribute\key\listener#preremove@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T16:35:39+01:00 */



$loaded = true;
$expiration = 1487950539;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTowOnt9'));

/* Child Type: integer */
$data['createdOn'] = 1487541300;
