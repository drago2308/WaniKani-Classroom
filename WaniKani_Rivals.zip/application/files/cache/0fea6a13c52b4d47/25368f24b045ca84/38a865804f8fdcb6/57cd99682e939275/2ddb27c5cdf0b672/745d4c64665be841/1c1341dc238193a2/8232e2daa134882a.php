<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\user\user@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T16:13:21+01:00 */



$loaded = true;
$expiration = 1487949201;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO047czo4OiJyZWFkT25seSI7YjowO31pOjE7TzoyNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcVGFibGUiOjU6e3M6NDoibmFtZSI7czo1OiJVc2VycyI7czo2OiJzY2hlbWEiO047czo3OiJpbmRleGVzIjthOjE6e2k6MDtPOjI2OiJEb2N0cmluZVxPUk1cTWFwcGluZ1xJbmRleCI6NDp7czo0OiJuYW1lIjtzOjY6InVFbWFpbCI7czo3OiJjb2x1bW5zIjthOjE6e2k6MDtzOjY6InVFbWFpbCI7fXM6NToiZmxhZ3MiO047czo3OiJvcHRpb25zIjtOO319czoxNzoidW5pcXVlQ29uc3RyYWludHMiO047czo3OiJvcHRpb25zIjthOjA6e319fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1487541297;
