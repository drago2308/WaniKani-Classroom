<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\key\key@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T11:32:19+01:00 */



$loaded = true;
$expiration = 1487932339;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTo1OntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO047czo4OiJyZWFkT25seSI7YjowO31pOjE7TzozNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcSW5oZXJpdGFuY2VUeXBlIjoxOntzOjU6InZhbHVlIjtzOjY6IkpPSU5FRCI7fWk6MjtPOjQwOiJEb2N0cmluZVxPUk1cTWFwcGluZ1xEaXNjcmltaW5hdG9yQ29sdW1uIjo1OntzOjQ6Im5hbWUiO3M6MTA6ImFrQ2F0ZWdvcnkiO3M6NDoidHlwZSI7czo2OiJzdHJpbmciO3M6NjoibGVuZ3RoIjtOO3M6OToiZmllbGROYW1lIjtOO3M6MTY6ImNvbHVtbkRlZmluaXRpb24iO047fWk6MztPOjM2OiJEb2N0cmluZVxPUk1cTWFwcGluZ1xFbnRpdHlMaXN0ZW5lcnMiOjE6e3M6NToidmFsdWUiO2E6MTp7aTowO3M6Mzc6IlxDb25jcmV0ZVxDb3JlXEF0dHJpYnV0ZVxLZXlcTGlzdGVuZXIiO319aTo0O086MjY6IkRvY3RyaW5lXE9STVxNYXBwaW5nXFRhYmxlIjo1OntzOjQ6Im5hbWUiO3M6MTM6IkF0dHJpYnV0ZUtleXMiO3M6Njoic2NoZW1hIjtOO3M6NzoiaW5kZXhlcyI7YToxOntpOjA7TzoyNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcSW5kZXgiOjQ6e3M6NDoibmFtZSI7czo1OiJwa2dJRCI7czo3OiJjb2x1bW5zIjthOjE6e2k6MDtzOjU6InBrZ0lEIjt9czo1OiJmbGFncyI7TjtzOjc6Im9wdGlvbnMiO047fX1zOjE3OiJ1bmlxdWVDb25zdHJhaW50cyI7TjtzOjc6Im9wdGlvbnMiO2E6MDp7fX19'));

/* Child Type: integer */
$data['createdOn'] = 1487541296;
