<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\express\entity\listener#postremove@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-28T15:23:47+01:00 */



$loaded = true;
$expiration = 1488291827;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTowOnt9'));

/* Child Type: integer */
$data['createdOn'] = 1487905042;
