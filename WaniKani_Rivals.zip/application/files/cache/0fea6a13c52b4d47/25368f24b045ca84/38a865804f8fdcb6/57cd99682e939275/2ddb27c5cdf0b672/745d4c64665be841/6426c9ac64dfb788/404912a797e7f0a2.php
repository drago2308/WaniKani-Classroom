<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\site\type$sites@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T15:53:53+01:00 */



$loaded = true;
$expiration = 1487948033;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7TzozMDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcT25lVG9NYW55Ijo2OntzOjg6Im1hcHBlZEJ5IjtzOjQ6InR5cGUiO3M6MTI6InRhcmdldEVudGl0eSI7czo0OiJTaXRlIjtzOjc6ImNhc2NhZGUiO2E6MTp7aTowO3M6NjoicmVtb3ZlIjt9czo1OiJmZXRjaCI7czo0OiJMQVpZIjtzOjEzOiJvcnBoYW5SZW1vdmFsIjtiOjA7czo3OiJpbmRleEJ5IjtOO319'));

/* Child Type: integer */
$data['createdOn'] = 1487541292;
