<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\value\legacyvalue@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T09:15:26+01:00 */



$loaded = true;
$expiration = 1487924126;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTowOnt9'));

/* Child Type: integer */
$data['createdOn'] = 1487541296;
