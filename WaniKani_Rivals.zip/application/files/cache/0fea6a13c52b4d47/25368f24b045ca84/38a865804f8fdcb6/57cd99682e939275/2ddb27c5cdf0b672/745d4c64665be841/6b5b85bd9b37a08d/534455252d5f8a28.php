<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\category$sets@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T19:44:19+01:00 */



$loaded = true;
$expiration = 1487961859;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTozOntpOjA7TzozMDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcT25lVG9NYW55Ijo2OntzOjg6Im1hcHBlZEJ5IjtzOjg6ImNhdGVnb3J5IjtzOjEyOiJ0YXJnZXRFbnRpdHkiO3M6MzoiU2V0IjtzOjc6ImNhc2NhZGUiO2E6MTp7aTowO3M6NjoicmVtb3ZlIjt9czo1OiJmZXRjaCI7czo0OiJMQVpZIjtzOjEzOiJvcnBoYW5SZW1vdmFsIjtiOjA7czo3OiJpbmRleEJ5IjtOO31pOjE7TzoyODoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcT3JkZXJCeSI6MTp7czo1OiJ2YWx1ZSI7YToxOntzOjE0OiJhc0Rpc3BsYXlPcmRlciI7czozOiJBU0MiO319aToyO086MzE6IkRvY3RyaW5lXE9STVxNYXBwaW5nXEpvaW5Db2x1bW4iOjc6e3M6NDoibmFtZSI7czoxMjoiYWtDYXRlZ29yeUlEIjtzOjIwOiJyZWZlcmVuY2VkQ29sdW1uTmFtZSI7czo0OiJhc0lEIjtzOjY6InVuaXF1ZSI7YjowO3M6ODoibnVsbGFibGUiO2I6MTtzOjg6Im9uRGVsZXRlIjtOO3M6MTY6ImNvbHVtbkRlZmluaXRpb24iO047czo5OiJmaWVsZE5hbWUiO047fX0='));

/* Child Type: integer */
$data['createdOn'] = 1487541301;
