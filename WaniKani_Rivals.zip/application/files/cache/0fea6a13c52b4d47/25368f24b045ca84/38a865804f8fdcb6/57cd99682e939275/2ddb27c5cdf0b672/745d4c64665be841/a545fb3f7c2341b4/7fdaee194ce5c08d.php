<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\key\userkey@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T16:03:46+01:00 */



$loaded = true;
$expiration = 1487948626;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO3M6NDY6IlxDb25jcmV0ZVxDb3JlXEVudGl0eVxVc2VyXEF0dHJpYnV0ZVJlcG9zaXRvcnkiO3M6ODoicmVhZE9ubHkiO2I6MDt9aToxO086MjY6IkRvY3RyaW5lXE9STVxNYXBwaW5nXFRhYmxlIjo1OntzOjQ6Im5hbWUiO3M6MTc6IlVzZXJBdHRyaWJ1dGVLZXlzIjtzOjY6InNjaGVtYSI7TjtzOjc6ImluZGV4ZXMiO047czoxNzoidW5pcXVlQ29uc3RyYWludHMiO047czo3OiJvcHRpb25zIjthOjA6e319fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1487541296;
