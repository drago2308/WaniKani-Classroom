<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\value\value\value$avid@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T11:59:28+01:00 */



$loaded = true;
$expiration = 1487933968;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTozOntpOjA7TzoyMzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcSWQiOjA6e31pOjE7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcQ29sdW1uIjo5OntzOjQ6Im5hbWUiO047czo0OiJ0eXBlIjtzOjc6ImludGVnZXIiO3M6NjoibGVuZ3RoIjtOO3M6OToicHJlY2lzaW9uIjtpOjA7czo1OiJzY2FsZSI7aTowO3M6NjoidW5pcXVlIjtiOjA7czo4OiJudWxsYWJsZSI7YjowO3M6Nzoib3B0aW9ucyI7YToxOntzOjg6InVuc2lnbmVkIjtiOjE7fXM6MTY6ImNvbHVtbkRlZmluaXRpb24iO047fWk6MjtPOjM1OiJEb2N0cmluZVxPUk1cTWFwcGluZ1xHZW5lcmF0ZWRWYWx1ZSI6MTp7czo4OiJzdHJhdGVneSI7czo0OiJBVVRPIjt9fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1487541301;
