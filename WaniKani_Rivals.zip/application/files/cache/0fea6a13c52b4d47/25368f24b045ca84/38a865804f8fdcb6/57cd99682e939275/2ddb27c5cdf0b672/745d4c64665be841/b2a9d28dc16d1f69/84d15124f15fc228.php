<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\value\uservalue$user@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-28T18:26:49+01:00 */



$loaded = true;
$expiration = 1488302809;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTozOntpOjA7TzoyMzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcSWQiOjA6e31pOjE7TzozMDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcTWFueVRvT25lIjo0OntzOjEyOiJ0YXJnZXRFbnRpdHkiO3M6MzE6IlxDb25jcmV0ZVxDb3JlXEVudGl0eVxVc2VyXFVzZXIiO3M6NzoiY2FzY2FkZSI7TjtzOjU6ImZldGNoIjtzOjQ6IkxBWlkiO3M6MTA6ImludmVyc2VkQnkiO047fWk6MjtPOjMxOiJEb2N0cmluZVxPUk1cTWFwcGluZ1xKb2luQ29sdW1uIjo3OntzOjQ6Im5hbWUiO3M6MzoidUlEIjtzOjIwOiJyZWZlcmVuY2VkQ29sdW1uTmFtZSI7czozOiJ1SUQiO3M6NjoidW5pcXVlIjtiOjA7czo4OiJudWxsYWJsZSI7YjoxO3M6ODoib25EZWxldGUiO047czoxNjoiY29sdW1uRGVmaW5pdGlvbiI7TjtzOjk6ImZpZWxkTmFtZSI7Tjt9fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1487905038;
