<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\express\entry\oneassociation@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T13:38:38+01:00 */



$loaded = true;
$expiration = 1487939918;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO047czo4OiJyZWFkT25seSI7YjowO319'));

/* Child Type: integer */
$data['createdOn'] = 1487541297;
