<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\user\usersignup$user@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-28T11:37:55+01:00 */



$loaded = true;
$expiration = 1488278275;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzoyOToiRG9jdHJpbmVcT1JNXE1hcHBpbmdcT25lVG9PbmUiOjY6e3M6MTI6InRhcmdldEVudGl0eSI7czozMToiXENvbmNyZXRlXENvcmVcRW50aXR5XFVzZXJcVXNlciI7czo4OiJtYXBwZWRCeSI7TjtzOjEwOiJpbnZlcnNlZEJ5IjtzOjY6InNpZ251cCI7czo3OiJjYXNjYWRlIjtOO3M6NToiZmV0Y2giO3M6NDoiTEFaWSI7czoxMzoib3JwaGFuUmVtb3ZhbCI7YjowO31pOjE7TzozMToiRG9jdHJpbmVcT1JNXE1hcHBpbmdcSm9pbkNvbHVtbiI6Nzp7czo0OiJuYW1lIjtzOjM6InVJRCI7czoyMDoicmVmZXJlbmNlZENvbHVtbk5hbWUiO3M6MzoidUlEIjtzOjY6InVuaXF1ZSI7YjowO3M6ODoibnVsbGFibGUiO2I6MTtzOjg6Im9uRGVsZXRlIjtOO3M6MTY6ImNvbHVtbkRlZmluaXRpb24iO047czo5OiJmaWVsZE5hbWUiO047fX0='));

/* Child Type: integer */
$data['createdOn'] = 1487905038;
