<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\value\value\abstractvalue@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-28T19:47:39+01:00 */



$loaded = true;
$expiration = 1488307659;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7TzozNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcTWFwcGVkU3VwZXJjbGFzcyI6MTp7czoxNToicmVwb3NpdG9yeUNsYXNzIjtOO319'));

/* Child Type: integer */
$data['createdOn'] = 1487905037;
