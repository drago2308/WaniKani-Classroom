<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\express\association@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T14:25:07+01:00 */



$loaded = true;
$expiration = 1487942707;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTo0OntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO047czo4OiJyZWFkT25seSI7YjowO31pOjE7TzozNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcSW5oZXJpdGFuY2VUeXBlIjoxOntzOjU6InZhbHVlIjtzOjEyOiJTSU5HTEVfVEFCTEUiO31pOjI7Tzo0MDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRGlzY3JpbWluYXRvckNvbHVtbiI6NTp7czo0OiJuYW1lIjtzOjQ6InR5cGUiO3M6NDoidHlwZSI7czo2OiJzdHJpbmciO3M6NjoibGVuZ3RoIjtOO3M6OToiZmllbGROYW1lIjtOO3M6MTY6ImNvbHVtbkRlZmluaXRpb24iO047fWk6MztPOjI2OiJEb2N0cmluZVxPUk1cTWFwcGluZ1xUYWJsZSI6NTp7czo0OiJuYW1lIjtzOjI1OiJFeHByZXNzRW50aXR5QXNzb2NpYXRpb25zIjtzOjY6InNjaGVtYSI7TjtzOjc6ImluZGV4ZXMiO047czoxNzoidW5pcXVlQ29uc3RyYWludHMiO047czo3OiJvcHRpb25zIjthOjA6e319fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1487541296;
