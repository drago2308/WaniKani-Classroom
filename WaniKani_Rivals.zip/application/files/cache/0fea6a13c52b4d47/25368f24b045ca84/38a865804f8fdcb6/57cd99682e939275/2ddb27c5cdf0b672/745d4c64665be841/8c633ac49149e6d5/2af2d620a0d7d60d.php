<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\stylecustomizer\inline\styleset$paddingtop@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-24T17:56:13+01:00 */



$loaded = true;
$expiration = 1487955373;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcQ29sdW1uIjo5OntzOjQ6Im5hbWUiO047czo0OiJ0eXBlIjtzOjY6InN0cmluZyI7czo2OiJsZW5ndGgiO047czo5OiJwcmVjaXNpb24iO2k6MDtzOjU6InNjYWxlIjtpOjA7czo2OiJ1bmlxdWUiO2I6MDtzOjg6Im51bGxhYmxlIjtiOjE7czo3OiJvcHRpb25zIjthOjA6e31zOjE2OiJjb2x1bW5EZWZpbml0aW9uIjtOO319'));

/* Child Type: integer */
$data['createdOn'] = 1487541299;
