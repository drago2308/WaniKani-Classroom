$(document).ready(function(){

//Give API key to browser
$('.api-add-btn').click(function(){
  //Get VARIABLES
  var api_key = $('.u-i-api-key').val();
  var func = 'add';
  if (api_key === ""){
    $('.u-i-api-key').val('No API Key Entered!');
  }else if (api_key === "No API Key Entered!") {
    $('.u-i-api-key').val('No API Key Entered!');
  }else{
    window.location.href = window.location.pathname + "?api_key=" + api_key + "&func=" + func;
  }
});

$('.api-add-btn-red').click(function(){
  //Get VARIABLES
  var api_key = $('.u-i-api-key').val();
  var func = 'delete';
  if (api_key === "" || api_key === "No API Key Entered!" || api_key.length < 31 ){
    api_key = "undefined";
    $('.popup-add-api').css('pointer-events', 'none');
    $('.popup-add-api').css('opacity', '0');
    $('.popup-add-api').css('margin-top', '6rem');
    $('.add-api-blackout').css('pointer-events', 'none');
    $('.add-api-blackout').css('opacity', '0');
    $('.popup-add-api-AF').css('pointer-events', 'none');
    $('.popup-add-api-AF').css('opacity', '0');
    $('.popup-add-api-AF').css('margin-top', '6rem');
    $('.add-api-blackout-AF').css('pointer-events', 'none');
    $('.add-api-blackout-AF').css('opacity', '0');
  }else {
    window.location.href = window.location.pathname + "?api_key=" + api_key + "&func=" + func;
  }
});


//Open
$('.add-api').click(function(){
  $('.popup-add-api').css('pointer-events', 'all');
  $('.popup-add-api').css('opacity', '1');
  $('.popup-add-api').css('margin-top', '3rem');
  $('.add-api-blackout').css('pointer-events', 'all');
  $('.add-api-blackout').css('opacity', '1');
});

});
