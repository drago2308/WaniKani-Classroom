<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\site\sitetree@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-15T01:05:26+01:00 */



$loaded = true;
$expiration = 1487117126;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTo0OntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO047czo4OiJyZWFkT25seSI7YjowO31pOjE7TzozNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcSW5oZXJpdGFuY2VUeXBlIjoxOntzOjU6InZhbHVlIjtzOjY6IkpPSU5FRCI7fWk6MjtPOjQwOiJEb2N0cmluZVxPUk1cTWFwcGluZ1xEaXNjcmltaW5hdG9yQ29sdW1uIjo1OntzOjQ6Im5hbWUiO3M6ODoidHJlZVR5cGUiO3M6NDoidHlwZSI7czo2OiJzdHJpbmciO3M6NjoibGVuZ3RoIjtOO3M6OToiZmllbGROYW1lIjtOO3M6MTY6ImNvbHVtbkRlZmluaXRpb24iO047fWk6MztPOjI2OiJEb2N0cmluZVxPUk1cTWFwcGluZ1xUYWJsZSI6NTp7czo0OiJuYW1lIjtzOjEzOiJTaXRlVHJlZVRyZWVzIjtzOjY6InNjaGVtYSI7TjtzOjc6ImluZGV4ZXMiO047czoxNzoidW5pcXVlQ29uc3RyYWludHMiO047czo3OiJvcHRpb25zIjthOjA6e319fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1486693040;
