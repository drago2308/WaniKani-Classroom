<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\user\user$signup@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T14:26:14+01:00 */



$loaded = true;
$expiration = 1487510774;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7TzoyOToiRG9jdHJpbmVcT1JNXE1hcHBpbmdcT25lVG9PbmUiOjY6e3M6MTI6InRhcmdldEVudGl0eSI7czozNzoiXENvbmNyZXRlXENvcmVcRW50aXR5XFVzZXJcVXNlclNpZ251cCI7czo4OiJtYXBwZWRCeSI7czo0OiJ1c2VyIjtzOjEwOiJpbnZlcnNlZEJ5IjtOO3M6NzoiY2FzY2FkZSI7YToxOntpOjA7czo2OiJyZW1vdmUiO31zOjU6ImZldGNoIjtzOjQ6IkxBWlkiO3M6MTM6Im9ycGhhblJlbW92YWwiO2I6MDt9fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1487111348;
