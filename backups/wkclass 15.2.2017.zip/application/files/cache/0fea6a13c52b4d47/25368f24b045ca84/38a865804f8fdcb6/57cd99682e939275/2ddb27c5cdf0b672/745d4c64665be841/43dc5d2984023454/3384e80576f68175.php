<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\user\user$attributes@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T09:11:07+01:00 */



$loaded = true;
$expiration = 1487491867;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzozMDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcT25lVG9NYW55Ijo2OntzOjg6Im1hcHBlZEJ5IjtzOjQ6InVzZXIiO3M6MTI6InRhcmdldEVudGl0eSI7czo0NzoiXENvbmNyZXRlXENvcmVcRW50aXR5XEF0dHJpYnV0ZVxWYWx1ZVxVc2VyVmFsdWUiO3M6NzoiY2FzY2FkZSI7YToxOntpOjA7czo2OiJyZW1vdmUiO31zOjU6ImZldGNoIjtzOjQ6IkxBWlkiO3M6MTM6Im9ycGhhblJlbW92YWwiO2I6MDtzOjc6ImluZGV4QnkiO047fWk6MTtPOjMxOiJEb2N0cmluZVxPUk1cTWFwcGluZ1xKb2luQ29sdW1uIjo3OntzOjQ6Im5hbWUiO3M6MzoidUlEIjtzOjIwOiJyZWZlcmVuY2VkQ29sdW1uTmFtZSI7czozOiJ1SUQiO3M6NjoidW5pcXVlIjtiOjA7czo4OiJudWxsYWJsZSI7YjoxO3M6ODoib25EZWxldGUiO047czoxNjoiY29sdW1uRGVmaW5pdGlvbiI7TjtzOjk6ImZpZWxkTmFtZSI7Tjt9fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1487111349;
