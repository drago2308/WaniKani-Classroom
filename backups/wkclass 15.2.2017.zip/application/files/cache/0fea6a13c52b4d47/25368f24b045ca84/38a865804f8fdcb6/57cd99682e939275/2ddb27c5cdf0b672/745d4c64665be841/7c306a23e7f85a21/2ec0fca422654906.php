<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\value\abstractvalue$generic_value@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T09:24:27+01:00 */



$loaded = true;
$expiration = 1487492667;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzozMDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcTWFueVRvT25lIjo0OntzOjEyOiJ0YXJnZXRFbnRpdHkiO3M6NDk6IlxDb25jcmV0ZVxDb3JlXEVudGl0eVxBdHRyaWJ1dGVcVmFsdWVcVmFsdWVcVmFsdWUiO3M6NzoiY2FzY2FkZSI7YToxOntpOjA7czo3OiJwZXJzaXN0Ijt9czo1OiJmZXRjaCI7czo0OiJMQVpZIjtzOjEwOiJpbnZlcnNlZEJ5IjtOO31pOjE7TzozMToiRG9jdHJpbmVcT1JNXE1hcHBpbmdcSm9pbkNvbHVtbiI6Nzp7czo0OiJuYW1lIjtzOjQ6ImF2SUQiO3M6MjA6InJlZmVyZW5jZWRDb2x1bW5OYW1lIjtzOjQ6ImF2SUQiO3M6NjoidW5pcXVlIjtiOjA7czo4OiJudWxsYWJsZSI7YjoxO3M6ODoib25EZWxldGUiO047czoxNjoiY29sdW1uRGVmaW5pdGlvbiI7TjtzOjk6ImZpZWxkTmFtZSI7Tjt9fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1487109423;
