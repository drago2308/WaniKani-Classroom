<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\express\entity$forms@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-17T09:20:11+01:00 */



$loaded = true;
$expiration = 1487319611;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7TzozMDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcT25lVG9NYW55Ijo2OntzOjg6Im1hcHBlZEJ5IjtzOjY6ImVudGl0eSI7czoxMjoidGFyZ2V0RW50aXR5IjtzOjQ6IkZvcm0iO3M6NzoiY2FzY2FkZSI7YToyOntpOjA7czo3OiJwZXJzaXN0IjtpOjE7czo2OiJyZW1vdmUiO31zOjU6ImZldGNoIjtzOjQ6IkxBWlkiO3M6MTM6Im9ycGhhblJlbW92YWwiO2I6MDtzOjc6ImluZGV4QnkiO047fX0='));

/* Child Type: integer */
$data['createdOn'] = 1486938090;
