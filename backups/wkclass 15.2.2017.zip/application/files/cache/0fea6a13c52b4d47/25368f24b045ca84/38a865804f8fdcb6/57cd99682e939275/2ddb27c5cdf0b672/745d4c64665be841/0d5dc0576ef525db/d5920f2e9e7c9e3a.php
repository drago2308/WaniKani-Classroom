<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\type$package@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-15T02:40:25+01:00 */



$loaded = true;
$expiration = 1487122825;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzozMDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcTWFueVRvT25lIjo0OntzOjEyOiJ0YXJnZXRFbnRpdHkiO3M6Mjk6IlxDb25jcmV0ZVxDb3JlXEVudGl0eVxQYWNrYWdlIjtzOjc6ImNhc2NhZGUiO2E6MTp7aTowO3M6NzoicGVyc2lzdCI7fXM6NToiZmV0Y2giO3M6NDoiTEFaWSI7czoxMDoiaW52ZXJzZWRCeSI7Tjt9aToxO086MzE6IkRvY3RyaW5lXE9STVxNYXBwaW5nXEpvaW5Db2x1bW4iOjc6e3M6NDoibmFtZSI7czo1OiJwa2dJRCI7czoyMDoicmVmZXJlbmNlZENvbHVtbk5hbWUiO3M6NToicGtnSUQiO3M6NjoidW5pcXVlIjtiOjA7czo4OiJudWxsYWJsZSI7YjoxO3M6ODoib25EZWxldGUiO047czoxNjoiY29sdW1uRGVmaW5pdGlvbiI7TjtzOjk6ImZpZWxkTmFtZSI7Tjt9fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1486693041;
