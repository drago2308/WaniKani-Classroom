<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\site\site$locales@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-15T02:44:12+01:00 */



$loaded = true;
$expiration = 1487123052;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzozMDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcT25lVG9NYW55Ijo2OntzOjg6Im1hcHBlZEJ5IjtzOjQ6InNpdGUiO3M6MTI6InRhcmdldEVudGl0eSI7czo2OiJMb2NhbGUiO3M6NzoiY2FzY2FkZSI7YToxOntpOjA7czozOiJhbGwiO31zOjU6ImZldGNoIjtzOjQ6IkxBWlkiO3M6MTM6Im9ycGhhblJlbW92YWwiO2I6MDtzOjc6ImluZGV4QnkiO047fWk6MTtPOjMxOiJEb2N0cmluZVxPUk1cTWFwcGluZ1xKb2luQ29sdW1uIjo3OntzOjQ6Im5hbWUiO3M6MTI6InNpdGVMb2NhbGVJRCI7czoyMDoicmVmZXJlbmNlZENvbHVtbk5hbWUiO3M6MTI6InNpdGVMb2NhbGVJRCI7czo2OiJ1bmlxdWUiO2I6MDtzOjg6Im51bGxhYmxlIjtiOjE7czo4OiJvbkRlbGV0ZSI7TjtzOjE2OiJjb2x1bW5EZWZpbml0aW9uIjtOO3M6OToiZmllbGROYW1lIjtOO319'));

/* Child Type: integer */
$data['createdOn'] = 1486693039;
