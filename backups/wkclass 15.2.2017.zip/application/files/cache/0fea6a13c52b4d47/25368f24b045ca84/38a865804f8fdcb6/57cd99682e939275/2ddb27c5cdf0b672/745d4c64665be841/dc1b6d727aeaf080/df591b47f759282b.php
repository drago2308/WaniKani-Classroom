<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\page\relation\multilingualrelation@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T07:02:15+01:00 */



$loaded = true;
$expiration = 1487484135;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO047czo4OiJyZWFkT25seSI7YjowO31pOjE7TzoyNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcVGFibGUiOjU6e3M6NDoibmFtZSI7czoyNToiTXVsdGlsaW5ndWFsUGFnZVJlbGF0aW9ucyI7czo2OiJzY2hlbWEiO047czo3OiJpbmRleGVzIjtOO3M6MTc6InVuaXF1ZUNvbnN0cmFpbnRzIjtOO3M6Nzoib3B0aW9ucyI7YTowOnt9fX0='));

/* Child Type: integer */
$data['createdOn'] = 1487109421;
