<?php 
/* Cachekey: cache/stash_default/doctrine/dc2_da83e9592ab334c754c82c58ea31ea34_[concrete\core\entity\attribute\value\abstractvalue$classmetadata][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T11:21:08+01:00 */



$loaded = true;
$expiration = 1487499668;

$data = array();

/* Child Type: object */
$data['return'] = unserialize(base64_decode('TzozNDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcQ2xhc3NNZXRhZGF0YSI6MTM6e3M6MTk6ImFzc29jaWF0aW9uTWFwcGluZ3MiO2E6MDp7fXM6MTE6ImNvbHVtbk5hbWVzIjthOjA6e31zOjEzOiJmaWVsZE1hcHBpbmdzIjthOjA6e31zOjEwOiJmaWVsZE5hbWVzIjthOjA6e31zOjE1OiJlbWJlZGRlZENsYXNzZXMiO2E6MDp7fXM6MTA6ImlkZW50aWZpZXIiO2E6MDp7fXM6MjE6ImlzSWRlbnRpZmllckNvbXBvc2l0ZSI7YjowO3M6NDoibmFtZSI7czo1MDoiQ29uY3JldGVcQ29yZVxFbnRpdHlcQXR0cmlidXRlXFZhbHVlXEFic3RyYWN0VmFsdWUiO3M6OToibmFtZXNwYWNlIjtzOjM2OiJDb25jcmV0ZVxDb3JlXEVudGl0eVxBdHRyaWJ1dGVcVmFsdWUiO3M6NToidGFibGUiO2E6MTp7czo0OiJuYW1lIjtzOjEzOiJBYnN0cmFjdFZhbHVlIjt9czoxNDoicm9vdEVudGl0eU5hbWUiO3M6NTA6IkNvbmNyZXRlXENvcmVcRW50aXR5XEF0dHJpYnV0ZVxWYWx1ZVxBYnN0cmFjdFZhbHVlIjtzOjExOiJpZEdlbmVyYXRvciI7TzozMzoiRG9jdHJpbmVcT1JNXElkXEFzc2lnbmVkR2VuZXJhdG9yIjowOnt9czoxODoiaXNNYXBwZWRTdXBlcmNsYXNzIjtiOjE7fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1487124623;
