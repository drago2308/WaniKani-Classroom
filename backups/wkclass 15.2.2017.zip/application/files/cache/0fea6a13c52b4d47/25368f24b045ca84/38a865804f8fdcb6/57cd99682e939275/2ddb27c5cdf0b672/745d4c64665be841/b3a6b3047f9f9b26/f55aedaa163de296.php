<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\statistics\usagetracker\fileusagerecord@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T21:35:57+01:00 */



$loaded = true;
$expiration = 1487536557;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO3M6NjU6IlxDb25jcmV0ZVxDb3JlXEVudGl0eVxTdGF0aXN0aWNzXFVzYWdlVHJhY2tlclxGaWxlVXNhZ2VSZXBvc2l0b3J5IjtzOjg6InJlYWRPbmx5IjtiOjA7fWk6MTtPOjI2OiJEb2N0cmluZVxPUk1cTWFwcGluZ1xUYWJsZSI6NTp7czo0OiJuYW1lIjtzOjE1OiJGaWxlVXNhZ2VSZWNvcmQiO3M6Njoic2NoZW1hIjtOO3M6NzoiaW5kZXhlcyI7YToyOntpOjA7TzoyNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcSW5kZXgiOjQ6e3M6NDoibmFtZSI7czo1OiJibG9jayI7czo3OiJjb2x1bW5zIjthOjE6e2k6MDtzOjg6ImJsb2NrX2lkIjt9czo1OiJmbGFncyI7TjtzOjc6Im9wdGlvbnMiO047fWk6MTtPOjI2OiJEb2N0cmluZVxPUk1cTWFwcGluZ1xJbmRleCI6NDp7czo0OiJuYW1lIjtzOjE4OiJjb2xsZWN0aW9uX3ZlcnNpb24iO3M6NzoiY29sdW1ucyI7YToyOntpOjA7czoxMzoiY29sbGVjdGlvbl9pZCI7aToxO3M6MjE6ImNvbGxlY3Rpb25fdmVyc2lvbl9pZCI7fXM6NToiZmxhZ3MiO047czo3OiJvcHRpb25zIjtOO319czoxNzoidW5pcXVlQ29uc3RyYWludHMiO047czo3OiJvcHRpb25zIjthOjA6e319fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1487109421;
