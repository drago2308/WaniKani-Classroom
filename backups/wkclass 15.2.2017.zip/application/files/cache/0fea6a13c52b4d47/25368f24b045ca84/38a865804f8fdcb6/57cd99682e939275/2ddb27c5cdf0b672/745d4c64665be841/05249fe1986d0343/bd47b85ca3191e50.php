<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\user\attributerepository@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T09:27:19+01:00 */



$loaded = true;
$expiration = 1487492839;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTowOnt9'));

/* Child Type: integer */
$data['createdOn'] = 1487109421;
