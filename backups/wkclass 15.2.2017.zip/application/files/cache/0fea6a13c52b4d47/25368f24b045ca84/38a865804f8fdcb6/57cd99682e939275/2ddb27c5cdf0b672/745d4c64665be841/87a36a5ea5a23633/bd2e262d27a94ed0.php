<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\search\query@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T20:42:53+01:00 */



$loaded = true;
$expiration = 1487533373;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7TzozMToiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW1iZWRkYWJsZSI6MDp7fX0='));

/* Child Type: integer */
$data['createdOn'] = 1487109421;
