<?php 
/* Cachekey: cache/stash_default/zend/zend_feed_reader_32cf6f1b9ec7fdf83da2b96ed1f32a3c/ */
/* Type: array */
/* Expiration: 2017-02-17T20:18:42+01:00 */



$loaded = true;
$expiration = 1487359122;

$data = array();

/* Child Type: string */
$data['return'] = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>
<rss version=\"2.0\" xmlns:slash=\"http://purl.org/rss/1.0/modules/slash/\">
  <channel>
    <title>concrete5.org Blog</title>
    <description>concrete5.org Blog</description>
    <generator>Zend_Feed_Writer 2 (http://framework.zend.com)</generator>
    <link>http://www.concrete5.org/about/blog</link>
    <item>
      <title>We're headed to PHPUK 2017!</title>
      <description><![CDATA[<p><img src=\"http://www.concrete5.org/application/files/8214/8665/9919/QaT2xBkT.png\" /></p>PHPUK is one of the largest PHP conferences in the world]]></description>
      <pubDate>Thu, 09 Feb 2017 17:02:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/news/were-headed-phpuk-2017</link>
      <guid>http://www.concrete5.org/about/blog/news/were-headed-phpuk-2017</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>concrete5 Version 8.1.0 and New Express Documentation Now Available</title>
      <description><![CDATA[New update adds some minor feature improvements and a bunch of bug fixes.]]></description>
      <pubDate>Tue, 24 Jan 2017 19:54:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/core-releases/concrete5-version-810-and-new-express-documentation-now-available</link>
      <guid>http://www.concrete5.org/about/blog/core-releases/concrete5-version-810-and-new-express-documentation-now-available</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>concrete5 8.0.3, 5.7.5.13 and New Documentation Now Available!</title>
      <description><![CDATA[Grab 8.0.3 to fix a bunch of 8.0 bugs, and learn about attributes.]]></description>
      <pubDate>Fri, 16 Dec 2016 18:43:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/core-releases/concrete5-803-57513-and-new-documentation-now-available</link>
      <guid>http://www.concrete5.org/about/blog/core-releases/concrete5-803-57513-and-new-documentation-now-available</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>concrete5 8.0.2 and 5.7.5.12 are released!</title>
      <description><![CDATA[Bug fixes and fixes for sites upgrading to version 8 are the order of the day.]]></description>
      <pubDate>Fri, 09 Dec 2016 18:06:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/core-releases/concrete5-802-and-57512-are-released</link>
      <guid>http://www.concrete5.org/about/blog/core-releases/concrete5-802-and-57512-are-released</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>concrete5 8.0.1 and 5.7.5.11 Released!</title>
      <description><![CDATA[<p><img src=\"http://www.concrete5.org/application/files/4914/6497/9925/concrete5_Logo_300x360.png\" /></p>Less than a week after 8.0, we have our first point release for concrete5 version 8.]]></description>
      <pubDate>Wed, 07 Dec 2016 18:37:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/core-releases/concrete5-801-and-57511-released</link>
      <guid>http://www.concrete5.org/about/blog/core-releases/concrete5-801-and-57511-released</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>A quick intro to Express in version 8</title>
      <description><![CDATA[Learn what Express can do for you and why you should use it. ]]></description>
      <pubDate>Mon, 05 Dec 2016 11:35:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/core-releases/quick-intro-express-version-8</link>
      <guid>http://www.concrete5.org/about/blog/core-releases/quick-intro-express-version-8</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>Version 8.0 and 5.7.5.10 Released Today!</title>
      <description><![CDATA[<p><img src=\"http://www.concrete5.org/application/files/4914/6497/9925/concrete5_Logo_300x360.png\" /></p>Christmas comes early as concrete5 releases its biggest update in two and a half years, and a major step forward for the platform.]]></description>
      <pubDate>Thu, 01 Dec 2016 18:23:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/core-releases/version-80-and-57510-released-today</link>
      <guid>http://www.concrete5.org/about/blog/core-releases/version-80-and-57510-released-today</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>concrete5 8.0RC2 Is Now Available!</title>
      <description><![CDATA[8.0 gets much, much closer.]]></description>
      <pubDate>Fri, 18 Nov 2016 20:10:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/community-blog/concrete5-80rc2-now-available</link>
      <guid>http://www.concrete5.org/about/blog/community-blog/concrete5-80rc2-now-available</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>concrete5 8.0RC1 Is Now Available!</title>
      <description><![CDATA[The future of concrete5 is coming – this month!]]></description>
      <pubDate>Fri, 04 Nov 2016 20:10:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/community-blog/concrete5-80rc1-now-available</link>
      <guid>http://www.concrete5.org/about/blog/community-blog/concrete5-80rc1-now-available</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>Concrete5 8.0.0 beta 6 is released</title>
      <description><![CDATA[<p><img src=\"http://www.concrete5.org/application/files/1014/6963/2211/beta-testers.png\" /></p>Still not quite production ready, but we're fixing bugs and adding refinement. 

]]></description>
      <pubDate>Fri, 21 Oct 2016 12:37:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/community-blog/concrete5-800-beta-6-released</link>
      <guid>http://www.concrete5.org/about/blog/community-blog/concrete5-800-beta-6-released</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>PHPStorm brings the thunder of awesome...</title>
      <description><![CDATA[PHPStorm is a great product, and you should check it out. ]]></description>
      <pubDate>Thu, 20 Oct 2016 04:57:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/community-blog/phpstorm-brings-thunder-awesome</link>
      <guid>http://www.concrete5.org/about/blog/community-blog/phpstorm-brings-thunder-awesome</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>Munich Meetup</title>
      <description><![CDATA[Come meet Franz in Germany at this München meetup]]></description>
      <pubDate>Sun, 16 Oct 2016 17:02:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/community-blog/munich-meetup</link>
      <guid>http://www.concrete5.org/about/blog/community-blog/munich-meetup</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>Join us in Slack</title>
      <description><![CDATA[We use Slack all day for work, now we've got an open source Slack for concrete5]]></description>
      <pubDate>Thu, 06 Oct 2016 08:18:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/open-source-strategy/join-us-slack</link>
      <guid>http://www.concrete5.org/about/blog/open-source-strategy/join-us-slack</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>UK Meetup was AWESOME!</title>
      <description><![CDATA[Thanks so much for such a great time in London gang!]]></description>
      <pubDate>Mon, 03 Oct 2016 12:36:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/community-blog/uk-meetup-was-awesome</link>
      <guid>http://www.concrete5.org/about/blog/community-blog/uk-meetup-was-awesome</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>Please vote.</title>
      <description><![CDATA[(With your mind, not your heart.)]]></description>
      <pubDate>Sun, 02 Oct 2016 03:28:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/philosophy-culture/please-vote</link>
      <guid>http://www.concrete5.org/about/blog/philosophy-culture/please-vote</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>PNWPHP 2016</title>
      <description><![CDATA[Saw and learned some awesome stuff at PNWPHP this year!]]></description>
      <pubDate>Tue, 20 Sep 2016 18:15:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/community-blog/pnwphp-2016</link>
      <guid>http://www.concrete5.org/about/blog/community-blog/pnwphp-2016</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>Concrete5 8.0.0 beta 2 is released</title>
      <description><![CDATA[<p><img src=\"http://www.concrete5.org/application/files/1014/6963/2211/beta-testers.png\" /></p>This version is good for site builders that are comfortable reporting and fixing bugs, and who are prepared to build their test sites from scratch. 

]]></description>
      <pubDate>Thu, 18 Aug 2016 12:37:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/core-releases/concrete5-800-beta-2-released</link>
      <guid>http://www.concrete5.org/about/blog/core-releases/concrete5-800-beta-2-released</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>What’s express doing in version 8?</title>
      <description><![CDATA[You’ve heard us talk about it, and it’s still bumpy in parts, but we’re eager to hear your feedback as you tinker around with Express in version 8 of concrete5. 
]]></description>
      <pubDate>Tue, 02 Aug 2016 14:24:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/core-roadmap/whats-express-doing-version-8</link>
      <guid>http://www.concrete5.org/about/blog/core-roadmap/whats-express-doing-version-8</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>Come Meetup In Europe</title>
      <description><![CDATA[If you live in Europe, I’d love to meet and say “Hi\" this fall. It’s wonderful to learn what people have built with concrete5.]]></description>
      <pubDate>Sun, 31 Jul 2016 21:39:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/news/come-meetup-europe</link>
      <guid>http://www.concrete5.org/about/blog/news/come-meetup-europe</guid>
      <slash:comments>0</slash:comments>
    </item>
    <item>
      <title>concrete5 Version 8.0.0. Beta 1 Released</title>
      <description><![CDATA[<p><img src=\"http://www.concrete5.org/application/files/1014/6963/2211/beta-testers.png\" /></p>Concrete5 8.0.0 beta 1 has been released for testing and feedback.
This version is good for site builders that are comfortable reporting and fixing bugs, and who are prepared to build their test sites from scratch.]]></description>
      <pubDate>Wed, 27 Jul 2016 10:55:00 +0000</pubDate>
      <link>http://www.concrete5.org/about/blog/core-releases/concrete5-version-800-beta-1-released</link>
      <guid>http://www.concrete5.org/about/blog/core-releases/concrete5-version-800-beta-1-released</guid>
      <slash:comments>0</slash:comments>
    </item>
  </channel>
</rss>
";

/* Child Type: integer */
$data['createdOn'] = 1486938101;
