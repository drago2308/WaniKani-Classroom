<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\page\relation\relation@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T16:08:55+01:00 */



$loaded = true;
$expiration = 1487516935;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7TzozNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcTWFwcGVkU3VwZXJjbGFzcyI6MTp7czoxNToicmVwb3NpdG9yeUNsYXNzIjtOO319'));

/* Child Type: integer */
$data['createdOn'] = 1487109421;
