<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\user\user$alerts@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T12:03:45+01:00 */



$loaded = true;
$expiration = 1487502225;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzozMDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcT25lVG9NYW55Ijo2OntzOjg6Im1hcHBlZEJ5IjtzOjQ6InVzZXIiO3M6MTI6InRhcmdldEVudGl0eSI7czo1MjoiXENvbmNyZXRlXENvcmVcRW50aXR5XE5vdGlmaWNhdGlvblxOb3RpZmljYXRpb25BbGVydCI7czo3OiJjYXNjYWRlIjthOjE6e2k6MDtzOjY6InJlbW92ZSI7fXM6NToiZmV0Y2giO3M6NDoiTEFaWSI7czoxMzoib3JwaGFuUmVtb3ZhbCI7YjowO3M6NzoiaW5kZXhCeSI7Tjt9aToxO086MzE6IkRvY3RyaW5lXE9STVxNYXBwaW5nXEpvaW5Db2x1bW4iOjc6e3M6NDoibmFtZSI7czozOiJ1SUQiO3M6MjA6InJlZmVyZW5jZWRDb2x1bW5OYW1lIjtzOjM6InVJRCI7czo2OiJ1bmlxdWUiO2I6MDtzOjg6Im51bGxhYmxlIjtiOjE7czo4OiJvbkRlbGV0ZSI7TjtzOjE2OiJjb2x1bW5EZWZpbml0aW9uIjtOO3M6OToiZmllbGROYW1lIjtOO319'));

/* Child Type: integer */
$data['createdOn'] = 1487111348;
