<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\site\locale$tree@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T06:25:57+01:00 */



$loaded = true;
$expiration = 1487481957;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzoyOToiRG9jdHJpbmVcT1JNXE1hcHBpbmdcT25lVG9PbmUiOjY6e3M6MTI6InRhcmdldEVudGl0eSI7czo4OiJTaXRlVHJlZSI7czo4OiJtYXBwZWRCeSI7czo2OiJsb2NhbGUiO3M6MTA6ImludmVyc2VkQnkiO047czo3OiJjYXNjYWRlIjthOjE6e2k6MDtzOjM6ImFsbCI7fXM6NToiZmV0Y2giO3M6NDoiTEFaWSI7czoxMzoib3JwaGFuUmVtb3ZhbCI7YjowO31pOjE7TzozMToiRG9jdHJpbmVcT1JNXE1hcHBpbmdcSm9pbkNvbHVtbiI6Nzp7czo0OiJuYW1lIjtzOjEwOiJzaXRlVHJlZUlEIjtzOjIwOiJyZWZlcmVuY2VkQ29sdW1uTmFtZSI7czoxMDoic2l0ZVRyZWVJRCI7czo2OiJ1bmlxdWUiO2I6MDtzOjg6Im51bGxhYmxlIjtiOjE7czo4OiJvbkRlbGV0ZSI7TjtzOjE2OiJjb2x1bW5EZWZpbml0aW9uIjtOO3M6OToiZmllbGROYW1lIjtOO319'));

/* Child Type: integer */
$data['createdOn'] = 1487109414;
