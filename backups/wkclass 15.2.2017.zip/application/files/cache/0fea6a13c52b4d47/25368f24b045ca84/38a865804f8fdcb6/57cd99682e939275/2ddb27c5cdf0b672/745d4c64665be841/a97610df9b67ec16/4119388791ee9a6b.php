<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\attribute\key\listener#preremove@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T22:35:29+01:00 */



$loaded = true;
$expiration = 1487540129;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTowOnt9'));

/* Child Type: integer */
$data['createdOn'] = 1487109422;
