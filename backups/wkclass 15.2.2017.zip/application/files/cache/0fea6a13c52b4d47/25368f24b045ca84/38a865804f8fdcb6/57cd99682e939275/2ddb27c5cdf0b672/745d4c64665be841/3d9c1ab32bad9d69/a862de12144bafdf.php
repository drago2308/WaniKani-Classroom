<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\key\key$category@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T22:35:39+01:00 */



$loaded = true;
$expiration = 1487540139;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToyOntpOjA7TzozMDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcTWFueVRvT25lIjo0OntzOjEyOiJ0YXJnZXRFbnRpdHkiO3M6NDA6IlxDb25jcmV0ZVxDb3JlXEVudGl0eVxBdHRyaWJ1dGVcQ2F0ZWdvcnkiO3M6NzoiY2FzY2FkZSI7TjtzOjU6ImZldGNoIjtzOjQ6IkxBWlkiO3M6MTA6ImludmVyc2VkQnkiO047fWk6MTtPOjMxOiJEb2N0cmluZVxPUk1cTWFwcGluZ1xKb2luQ29sdW1uIjo3OntzOjQ6Im5hbWUiO3M6MTI6ImFrQ2F0ZWdvcnlJRCI7czoyMDoicmVmZXJlbmNlZENvbHVtbk5hbWUiO3M6MTI6ImFrQ2F0ZWdvcnlJRCI7czo2OiJ1bmlxdWUiO2I6MDtzOjg6Im51bGxhYmxlIjtiOjE7czo4OiJvbkRlbGV0ZSI7TjtzOjE2OiJjb2x1bW5EZWZpbml0aW9uIjtOO3M6OToiZmllbGROYW1lIjtOO319'));

/* Child Type: integer */
$data['createdOn'] = 1487109422;
