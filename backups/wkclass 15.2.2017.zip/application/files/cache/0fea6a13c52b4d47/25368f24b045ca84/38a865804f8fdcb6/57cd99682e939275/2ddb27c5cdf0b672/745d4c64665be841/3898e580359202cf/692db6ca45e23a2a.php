<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\value\value\selectvalueusedoption@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-15T03:01:29+01:00 */



$loaded = true;
$expiration = 1487124089;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTowOnt9'));

/* Child Type: integer */
$data['createdOn'] = 1486693040;
