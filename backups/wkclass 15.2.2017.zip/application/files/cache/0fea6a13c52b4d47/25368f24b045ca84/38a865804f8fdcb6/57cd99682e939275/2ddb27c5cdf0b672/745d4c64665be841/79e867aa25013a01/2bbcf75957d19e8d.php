<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\express\entity@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-15T01:47:38+01:00 */



$loaded = true;
$expiration = 1487119658;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTozOntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO3M6NDY6IlxDb25jcmV0ZVxDb3JlXEVudGl0eVxFeHByZXNzXEVudGl0eVJlcG9zaXRvcnkiO3M6ODoicmVhZE9ubHkiO2I6MDt9aToxO086MjY6IkRvY3RyaW5lXE9STVxNYXBwaW5nXFRhYmxlIjo1OntzOjQ6Im5hbWUiO3M6MTU6IkV4cHJlc3NFbnRpdGllcyI7czo2OiJzY2hlbWEiO047czo3OiJpbmRleGVzIjtOO3M6MTc6InVuaXF1ZUNvbnN0cmFpbnRzIjtOO3M6Nzoib3B0aW9ucyI7YTowOnt9fWk6MjtPOjM2OiJEb2N0cmluZVxPUk1cTWFwcGluZ1xFbnRpdHlMaXN0ZW5lcnMiOjE6e3M6NToidmFsdWUiO2E6MTp7aTowO3M6Mzg6IlxDb25jcmV0ZVxDb3JlXEV4cHJlc3NcRW50aXR5XExpc3RlbmVyIjt9fX0='));

/* Child Type: integer */
$data['createdOn'] = 1486693040;
