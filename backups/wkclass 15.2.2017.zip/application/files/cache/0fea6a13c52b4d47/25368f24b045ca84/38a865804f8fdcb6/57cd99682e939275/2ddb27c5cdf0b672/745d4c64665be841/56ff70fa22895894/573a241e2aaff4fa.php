<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\type$controller@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-14T23:37:53+01:00 */



$loaded = true;
$expiration = 1487111873;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTowOnt9'));

/* Child Type: integer */
$data['createdOn'] = 1486693041;
