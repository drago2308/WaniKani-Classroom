<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\user\user$ulastip@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T07:36:32+01:00 */



$loaded = true;
$expiration = 1487486192;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcQ29sdW1uIjo5OntzOjQ6Im5hbWUiO047czo0OiJ0eXBlIjtzOjQ6InRleHQiO3M6NjoibGVuZ3RoIjtOO3M6OToicHJlY2lzaW9uIjtpOjA7czo1OiJzY2FsZSI7aTowO3M6NjoidW5pcXVlIjtiOjA7czo4OiJudWxsYWJsZSI7YjoxO3M6Nzoib3B0aW9ucyI7YTowOnt9czoxNjoiY29sdW1uRGVmaW5pdGlvbiI7Tjt9fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1487111349;
