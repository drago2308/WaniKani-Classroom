<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\express\entity$attributes@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-17T12:20:03+01:00 */



$loaded = true;
$expiration = 1487330403;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7TzozMDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcT25lVG9NYW55Ijo2OntzOjg6Im1hcHBlZEJ5IjtzOjY6ImVudGl0eSI7czoxMjoidGFyZ2V0RW50aXR5IjtzOjQ2OiJcQ29uY3JldGVcQ29yZVxFbnRpdHlcQXR0cmlidXRlXEtleVxFeHByZXNzS2V5IjtzOjc6ImNhc2NhZGUiO2E6Mjp7aTowO3M6NzoicGVyc2lzdCI7aToxO3M6NjoicmVtb3ZlIjt9czo1OiJmZXRjaCI7czo0OiJMQVpZIjtzOjEzOiJvcnBoYW5SZW1vdmFsIjtiOjA7czo3OiJpbmRleEJ5IjtOO319'));

/* Child Type: integer */
$data['createdOn'] = 1486938090;
