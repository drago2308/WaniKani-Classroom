<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\express\entity$created_date@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-17T22:37:09+01:00 */



$loaded = true;
$expiration = 1487367429;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcQ29sdW1uIjo5OntzOjQ6Im5hbWUiO047czo0OiJ0eXBlIjtzOjg6ImRhdGV0aW1lIjtzOjY6Imxlbmd0aCI7TjtzOjk6InByZWNpc2lvbiI7aTowO3M6NToic2NhbGUiO2k6MDtzOjY6InVuaXF1ZSI7YjowO3M6ODoibnVsbGFibGUiO2I6MDtzOjc6Im9wdGlvbnMiO2E6MDp7fXM6MTY6ImNvbHVtbkRlZmluaXRpb24iO047fX0='));

/* Child Type: integer */
$data['createdOn'] = 1486938090;
