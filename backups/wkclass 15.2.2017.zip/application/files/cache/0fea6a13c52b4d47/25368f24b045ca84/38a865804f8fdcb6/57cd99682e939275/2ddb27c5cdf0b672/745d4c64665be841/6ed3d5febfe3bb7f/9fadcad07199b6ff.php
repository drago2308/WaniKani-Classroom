<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\express\entity\listener#postremove@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-17T17:46:29+01:00 */



$loaded = true;
$expiration = 1487349989;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTowOnt9'));

/* Child Type: integer */
$data['createdOn'] = 1486938090;
