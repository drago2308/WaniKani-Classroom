<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\user\usersignup$notifications@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T21:55:09+01:00 */



$loaded = true;
$expiration = 1487537709;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7TzozMDoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcT25lVG9NYW55Ijo2OntzOjg6Im1hcHBlZEJ5IjtzOjY6InNpZ251cCI7czoxMjoidGFyZ2V0RW50aXR5IjtzOjU3OiJcQ29uY3JldGVcQ29yZVxFbnRpdHlcTm90aWZpY2F0aW9uXFVzZXJTaWdudXBOb3RpZmljYXRpb24iO3M6NzoiY2FzY2FkZSI7YToxOntpOjA7czo2OiJyZW1vdmUiO31zOjU6ImZldGNoIjtzOjQ6IkxBWlkiO3M6MTM6Im9ycGhhblJlbW92YWwiO2I6MDtzOjc6ImluZGV4QnkiO047fX0='));

/* Child Type: integer */
$data['createdOn'] = 1487111349;
