<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\attribute\type$categories@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-19T22:31:10+01:00 */



$loaded = true;
$expiration = 1487539870;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7TzozMToiRG9jdHJpbmVcT1JNXE1hcHBpbmdcTWFueVRvTWFueSI6Nzp7czoxMjoidGFyZ2V0RW50aXR5IjtzOjg6IkNhdGVnb3J5IjtzOjg6Im1hcHBlZEJ5IjtzOjU6InR5cGVzIjtzOjEwOiJpbnZlcnNlZEJ5IjtOO3M6NzoiY2FzY2FkZSI7TjtzOjU6ImZldGNoIjtzOjQ6IkxBWlkiO3M6MTM6Im9ycGhhblJlbW92YWwiO2I6MDtzOjc6ImluZGV4QnkiO047fX0='));

/* Child Type: integer */
$data['createdOn'] = 1487111348;
