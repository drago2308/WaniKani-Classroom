<?php 
/* Cachekey: cache/stash_default/doctrine/[concrete\core\entity\express\control\control@[annot]][1]/ */
/* Type: array */
/* Expiration: 2017-02-14T23:44:08+01:00 */



$loaded = true;
$expiration = 1487112248;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YTo0OntpOjA7TzoyNzoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcRW50aXR5IjoyOntzOjE1OiJyZXBvc2l0b3J5Q2xhc3MiO047czo4OiJyZWFkT25seSI7YjowO31pOjE7TzozNjoiRG9jdHJpbmVcT1JNXE1hcHBpbmdcSW5oZXJpdGFuY2VUeXBlIjoxOntzOjU6InZhbHVlIjtzOjY6IkpPSU5FRCI7fWk6MjtPOjQwOiJEb2N0cmluZVxPUk1cTWFwcGluZ1xEaXNjcmltaW5hdG9yQ29sdW1uIjo1OntzOjQ6Im5hbWUiO3M6NDoidHlwZSI7czo0OiJ0eXBlIjtzOjY6InN0cmluZyI7czo2OiJsZW5ndGgiO047czo5OiJmaWVsZE5hbWUiO047czoxNjoiY29sdW1uRGVmaW5pdGlvbiI7Tjt9aTozO086MjY6IkRvY3RyaW5lXE9STVxNYXBwaW5nXFRhYmxlIjo1OntzOjQ6Im5hbWUiO3M6Mjc6IkV4cHJlc3NGb3JtRmllbGRTZXRDb250cm9scyI7czo2OiJzY2hlbWEiO047czo3OiJpbmRleGVzIjtOO3M6MTc6InVuaXF1ZUNvbnN0cmFpbnRzIjtOO3M6Nzoib3B0aW9ucyI7YTowOnt9fX0='));

/* Child Type: integer */
$data['createdOn'] = 1486693040;
