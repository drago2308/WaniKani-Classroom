<?php

return [
    'canonical-url' => '',
    'canonical-ssl-url' => '',
];
